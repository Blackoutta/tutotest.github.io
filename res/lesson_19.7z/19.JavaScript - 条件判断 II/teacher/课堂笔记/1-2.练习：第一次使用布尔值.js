1. 首先把以下三个变量复制到'scripts.js'文件中：

var classOne = '计应1班';
var classTwo = '计应2班';
var classThree = '移动互联及信安信管';
var isClassOne = false;
var isClassTwo = false;
var isClassThree = false;

2. 然后根据你的班级，将上方某个 var isClassXXX 的值更新为'true';

3. 最后，使用条件判断句写下以下代码：

if (isClassOne) {
    alert('欢迎，' + classOne + '的同学！');
} else if (isClassTwo) {
    alert('欢迎，' + classTwo + '的同学！');
} else if (isClassThree) {
    alert('欢迎，' + classThree + '的同学！');
} else {
    alert('同学你谁？^_^');
}