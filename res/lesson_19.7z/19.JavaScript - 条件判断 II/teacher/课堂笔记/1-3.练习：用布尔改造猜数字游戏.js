上节课，我们做了一个猜数字游戏，但是其中并没有使用布尔，虽然程序运行良好，但是从规范角度来讲还是差了点。
所以现在我们要运用刚才学到的更新布尔的方法来改造这段程序，让它变得更灵活，为我们之后进一步增加游戏机制做准备。

'上节课'的代码如下：
var randomNumber = Math.floor(Math.random() * 6) + 1;
var guess = prompt('我心中浮现了一个数字，它介于1-6之间，猜猜是哪个数字？');
if (parseInt(guess) === randomNumber) {
     document.write('<p>猜对了！</p>');
} else if (isNaN(guess) || guess === '' || guess > 6 || guess < 1) {
    alert('请输入一个1-6之间的数字！');
} else {
    document.write('<p>猜错了！</p>');
} 

'改造后'的代码为：
var randomNumber = Math.floor(Math.random() * 6) + 1;
var guess = prompt('我心中浮现了一个数字，它介于1-6之间，猜猜是哪个数字？');
var correctGuess = false; //变量名意为'猜测正确'，一开始用户没有猜，我们默认它是false

if (parseInt(guess) === randomNumber) {
     correctGuess = true;
} 

if (correctGuess /*这里也可以写correctGuess === true， 但是由于上方已经将这个变量更新为true了，故这里不用写 '=== true'*/){
    document.write('猜对咯！你真棒！');
} else if (isNaN(guess) || guess === '' || guess > 6 || guess < 1) {  //用来防止用户提交错误的信息
    alert('请输入一个1-6之间的数字！');
} else {
    document.write('猜错了，刚才的数字是' + randomNumber + '哦~~~');
}


