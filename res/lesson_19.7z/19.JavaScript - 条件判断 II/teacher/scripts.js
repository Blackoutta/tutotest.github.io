//设定变量
var classOne = '计应1班';
var classTwo = '计应2班';
var classThree = '移动互联及信安信管';
var isClassOne = false;  //这里的变量都是布尔，初始全部设定为false
var isClassTwo = false;
var isClassThree = false;

isClassOne = true;  //如果是一班的同学，则将isClassOne这个变量更新为true

if (isClassOne) {  //直接将变量写到if的条件判断区域内，由于上方已经将该变量更新为true，所以这个判断直接成立，随即马上运行下方的语句
    alert('欢迎，' + classOne + '的同学！');
} else if (isClassTwo) {
    alert('欢迎，' + classTwo + '的同学！');
} else if (isClassThree) {
    alert('欢迎，' + classThree + '的同学！');
} else {
    alert('这位同学，你是哪个班的？^_^');
}



