var randomNumber = Math.floor(Math.random() * 6) + 1;
var guess = prompt('我心中浮现了一个数字，它介于1-6之间，猜猜是哪个数字？');
var correctGuess = false; //变量名意为'猜测正确'，一开始用户没有猜，我们默认它是false

if (parseInt(guess) === randomNumber) {
     correctGuess = true;
} 

if (correctGuess /*这里也可以写correctGuess === true， 但是由于上方已经将这个变量更新为true了，故这里不用写 '=== true'*/){
    document.write('猜对咯！你真棒！');
} else if (isNaN(guess) || guess === '' || guess > 6 || guess < 1) {  //用来防止用户提交错误的信息
    alert('请输入一个1-6之间的数字！');
} else {
    document.write('猜错了，刚才的数字是' + randomNumber + '哦~~~');
}
