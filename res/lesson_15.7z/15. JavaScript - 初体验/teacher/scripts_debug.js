alert("JavaScript，启动！");
console.log("JavaScript,启动！");

alert("开始书写网页元素！");
console.log("开始书写网页元素！");

document.write("欢迎来到JavaScript，它非常适合作为你的第一门计算机语言！");
document.write("<h1>因为JS可以通过浏览器运行，可以很直观地看到程序的效果，并且利用浏览器进行排错也是很方便的！</h1>");

alert("网页元素，书写完毕！");
console.log("网页元素，书写完毕！");

alert("程序执行完毕，enjoy!");
console.log("程序执行完毕，enjoy!");