JS函数不仅仅能够返回值，还能传递值(passin)

句法如下：

function passIn(canshu) {   //括号中的值叫做parameter或argument，意为参数。参数名称可以自行设置
    document.write(canshu);//把上方命名的参数传递到下方的语句中使用;
}
passIn('这就是参数的传递！');


你还可以传递多个参数：

function passIn(canshu1, canshu2) {
    document.write(canshu1 + canshu2);
}
passIn('字符串', 123);