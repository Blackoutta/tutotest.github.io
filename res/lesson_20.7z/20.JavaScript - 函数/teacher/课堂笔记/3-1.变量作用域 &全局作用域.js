在JS中，有个编程概念叫作用域(scope)，你可以理解成不同维度的宇宙。
两个不同的函数是两个不同的作用域；
函数区域和非函数区域又是两个不同的作用域；非函数区域被称作全局作用域(global scope)
'在不同作用域中可以设置相同的变量名，且这两个变量互不干扰'；

我们来看个例子：

function marvel() {
    var hero = '钢铁侠';
    document.write(hero + '<br/>');
}

function dc() {
    var hero = '蝙蝠侠';
    document.write(hero + '<br/>');
}

var hero = '雷锋侠';

marvel();
dc();
document.write(hero);