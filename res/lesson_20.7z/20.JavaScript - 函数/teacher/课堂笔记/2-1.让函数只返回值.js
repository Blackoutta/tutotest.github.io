在程序中，有一个很常见的手法：创建一个函数，让它不做其他事，而'只是返回一个值'。之后，编程者便可以将这个值用在多个语句中。可谓'为所欲为'; 

句法：


function returnTest() {
    return 'return可以返回字符串，数字，和布尔哦！';
}

alert(returnTest());
console.log(returnTest());
var tutorial = returnTest();