1. return 这个命令一旦被程序读到，程序会马上离开当前函数的代码区;
   所以 return 语句一定要放在函数代码区的'最后一行'
例子:
function noAlert() {
    return 5;
    alert ('这条语句不会被执行');
}
noAlert ();


2. return 只能返回'一个'值。
下面这个例子就是'错误'的:
function test() {
    return 5, 6, 7, 8;
}