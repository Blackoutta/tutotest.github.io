function diceRoll(lower, upper) {
    var randomNumber = Math.floor(Math.random() * (upper - lower + 1)) + lower; 
    document.write('你扔出了' + randomNumber + '!（' + lower + '-' + upper + '）');
}

diceRoll(50-60);