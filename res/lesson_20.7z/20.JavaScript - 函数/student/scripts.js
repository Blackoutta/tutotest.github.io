function getDrink(budget) {   
    if(budget >= 20) {
        return '带回了拿铁';
    } else if(budget >= 10) {
        return '带回了奶茶';
    } else if (budget > 0) {
        return '带回了矿泉水';
    } else {
        return '什么都没有带回来';
    }
}
document.write('xxx去了趟咖啡厅，并' + getDrink(30));