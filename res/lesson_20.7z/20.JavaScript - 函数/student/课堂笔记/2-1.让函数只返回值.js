在程序中，有一个很常见的手法：创建一个函数，让它不做其他事，而'只是返回一个值'。之后，编程者便可以将这个值用在多个语句中。可谓'为所欲为'; 

return一般会跟'参数传递'和'条件判断句'配合使用！

句法：


function goToStarBucks() {
    return '拿铁';
}

var coffee = goToStarBucks();
document.write(coffee);
console.log('xxx带回来了一杯' + coffee);