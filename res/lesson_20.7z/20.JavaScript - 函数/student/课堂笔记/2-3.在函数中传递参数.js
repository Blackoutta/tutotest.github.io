JS函数不仅仅能够返回值，还能传递值(passin)

句法如下：
function goToStarBucks(coffee) {   //括号中的值叫做parameter或argument，意为参数。参数名称可以自行设置
    document.write('xxx带回了' + coffee);//把上方命名的参数传递到下方的语句中使用;
}
goToStarBucks('拿铁');








你还可以传递多个参数：
function goToStarBucks(coffee, food) {   
    document.write('xxx带回了' + coffee + '和' + food);
}
goToStarBucks('拿铁', '牛肉汉堡');