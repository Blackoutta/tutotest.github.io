"use strict";
//Phase 1 get element by id
//Phase 1 get element by id
const myHeading = document.getElementById('myHeading');
const myButton = document.getElementById('myButton');
const myTextInput = document.getElementById('myTextInput');
const resetBlack = document.getElementById('resetBlack');

function changeHeadingColor() {
    myHeading.style.color = myTextInput.value;
}

function reset() {
    myHeading.style.color = 'black';
    myTextInput.value = '';
}

myButton.addEventListener('click', changeHeadingColor);
resetBlack.addEventListener('click', reset);




//Phase 2 get elements by tag
//Phase 2 get elements by tag
const myList = document.getElementsByTagName('li');

for (let i = 0; i < myList.length; i += 1) {
    myList[i].style.color = 'purple';
}



//Phase 3 get elements by class
//Phase 3 get elements by class
const notPurple = document.getElementsByClassName('notPurple');

for (let i = 0; i < notPurple.length; i += 1) {
    notPurple[i].style.color = 'red';
}




//Phase 4 querySelectors
//Phase 4 querySelectors

const evens = document.querySelectorAll('li:nth-child(even)');

for (let i = 0; i < evens.length; i += 1) {
    evens[i].style.backgroundColor = 'lightgray';
}