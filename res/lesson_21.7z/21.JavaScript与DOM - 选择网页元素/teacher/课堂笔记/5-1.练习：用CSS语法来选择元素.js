document.querySelector('在CSS中怎么选元素，在这里就怎么写') 
或
document.querySelectorAll('在CSS中怎么选元素，在这里就怎么写')
他们的区别你可以自己在后台试试，或者查询MDN

相比于之前我们学过的三种选择元素的方法，queryselector是比较新的method，可以让你用CSS语法来选择网页中的元素
通常，为了方便使用，我们会将上面的语句存进一个 const(常量)中，这样就可以将它做成一个对象


1. 加入以下代码：

const evens = document.querySelectorAll('li:nth-child(even)');

for (let i = 0; i < evens.length; i += 1) {
    evens[i].style.backgroundColor = 'lightgray';
}




2. 然后将刚才有 .getElementsByTagName 和 .getElementsByClassName 的语句，修改为：

const myList = document.querySelectorAll('li');
for (let i = 0; i < myList.length; i++) {
    myList[i].style.color = 'purple';
}

const notPurple = document.querySelectorAll('.notPurple');
for (let i = 0; i < notPurple.length; i += 1) {
    notPurple[i].style.color = 'red';
}