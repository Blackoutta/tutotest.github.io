DOM的全称是 Document Object Model，文档对象模型

以前我们用过document.write();

'document'是对象(object)，'.write' 是方法(method); 用游戏思维来理解就是，'document'是英雄，而 '.write' 是技能。

document在专业术语里被称为'全局变量'，它是一个变量，它代表了'当前你正在编辑的HTML页面'。

刚才我们也通过一系列JS语句来操作HTML文档里面的元素，让网页得到了改变。所以，'JavaScript可以操作的网页'这个存在本身就被称之为'DOM'。

你可以这样理解：'DOM'就是一份地图，它可以帮助你'定位'网页上的元素；但是这个地图还是活的，你定位到元素后，你还能直接在地图的世界中'改变/新增'更多的元素；