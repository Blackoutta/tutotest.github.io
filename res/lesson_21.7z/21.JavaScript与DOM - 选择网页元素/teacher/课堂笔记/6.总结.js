用JavaScript和DOM，我们只需要三个步骤便能为网页增加互动性：

1. 选择网页元素   （网页需要知道你想要修改'哪些地方'）
2. 操作网页元素   （网页需要知道你想要'做什么修改'）
3. 听取用户动作   （网页需要知道用户做了什么事情'才会发生上面的修改'）


我们学习了三种经典的method来选择网页中的元素：
.getElementById              用ID来选择元素
.getElementsByTagName        用标签来选择元素
.getElementsByClassName      用Class来选择元素


我们学习了一种比较新的method，它可以让你用CSS语法来选择元素：
.querySelector
.querySelectorAll


我们尝试了使用for loop，来为选中的多个元素迭代样式
for (let i = 0; i < myList.length; i += 1) {
    myList[i].style.color = 'purple';
}

我们还用数组顺序选择符号：[n] 来选择多个元素中的某一个元素： 注意，在数组中，第一个数据的编号是： 0
const myList = document.getElementsByTagName('li')[0];
myList.style.color = 'red';