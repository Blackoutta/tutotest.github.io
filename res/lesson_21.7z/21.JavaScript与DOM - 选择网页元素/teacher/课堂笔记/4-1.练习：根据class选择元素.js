document.getElementsByClassName('这里填HTML中class的名字') 可以为你选择HTML文档中的class元素
通常，为了方便使用，我们会将上面的语句存进一个 const(常量)中，这样就可以将它做成一个对象

在已有的代码中加入以下代码：
const notPurple = document.getElementsByClassName('notPurple');

for (let i = 0; i < notPurple.length; i += 1) {
    notPurple[i].style.color = 'red';
}
