document.getElementsByTagName('这里填HTML中标签的名字') 可以为你选择HTML文档中的标签元素
通常，为了方便使用，我们会将上面的语句存进一个 const(常量)中，这样就可以将它做成一个对象

1. 加入以下代码：
const myList = document.getElementsByTagName('li');
myList.style.color = 'red';

看看有什么效果。



2. 再将代码变更为：
const myList = document.getElementsByTagName('li')[0];
myList.style.color = 'red';

看看有什么效果。

3. 再将代码变更为：
const myList = document.getElementsByTagName('li');
for (let i = 0; i < myList.length; i += 1) {
    myList[i].style.color = 'purple';
}