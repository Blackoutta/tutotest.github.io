document.getElementById('这里填HTML中ID的名字') 可以为你选择HTML文档中设定了ID的元素
通常，为了方便使用，我们会将上面的语句存进一个 const(常量)中，这样就可以将它做成一个对象。

1. 我们先在HTML中加一个输入框： <input type="text" id="myTextInput">

2. 然后还是在HTML中，加入一个按钮： <button id="myButton">改变标题颜色</button>

3. 回到 'app.js'文件中，修改代码为：
const myHeading = document.getElementById('myHeading');    //将标题元素做成对象
const myButton = document.getElementById('myButton');      //将按钮元素做成对象
const myTextInput = document.getElementById('myTextInput'); //将输入框元素做成对象

function changeHeadingColor() {
    myHeading.style.color = myTextInput.value;          //让标题的 颜色 等于输入框元素的 值
}

myButton.addEventListener('click', changeHeadingColor);  //按钮元素听令，用户一旦点击按钮，执行上方的函数