想要使用JS为网页添加互动性，那么你只需要记住以下三个步骤：

1. 选择网页元素   （网页需要知道你想要修改'哪些地方'）
2. 操作网页元素   （网页需要知道你想要'做什么修改'）
3. 听取用户动作   （网页需要知道用户做了什么事情'才会发生上面的修改'）

我们来试个例子：
1. 打开今天的网页，然后打开后台（CTRL+SHIFT+J '谷歌'/CTRL+SHIFT+K '火狐'）

输入：document.getElementById('myHeading')  这时候后台会返回一个'网页元素'

然后将语句改为：document.getElementById('myHeading').style.color = 'red'  这时候标题会变为红色  

现在我们已经做到了前两步：'选择元素'和'操作元素'，就差'听取用户动作'了

2. 在 'app.js'文件中，输入：

const myHeading = document.getElementById('myHeading');   //选择元素，并将该元素变成一个常量，这样我们所选取的元素就变成了一个对象

function changeHeadingColor() {                           //将我们要做的修改做成一个函数
    myHeading.style.color = 'red';
}

myHeading.addEventListener('click', changeHeadingColor); //告诉对象，现在听令，只要用户在元素上点击鼠标(click)，就运行我们刚才写的函数

3. 在网页中点击标题，看看有无变化。