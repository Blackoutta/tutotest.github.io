var userName = prompt('请问阁下尊姓大名？');
var favoriteGame = prompt('请问你最近在玩什么游戏？');
var thingsToDo= prompt('请问你现在在做什么？');

var story = userName + '沉迷';
story += favoriteGame + '无法自拔，';
story += '以至于今天他忘记了' + thingsToDo;

document.write(story);