//知识点1：操纵HTML标签中的内容与属性
//知识点1：操纵HTML标签中的内容与属性
const descriptionInput = document.querySelector('input.description');
const descriptionP = document.querySelector('p.description');
const descriptionButton = document.querySelector('button.description');
//用户点击按钮时，改变按钮旁边的标题
descriptionButton.addEventListener('click', () => {
  descriptionP.innerHTML = descriptionInput.value + ':';
  descriptionInput.value = '';
});
