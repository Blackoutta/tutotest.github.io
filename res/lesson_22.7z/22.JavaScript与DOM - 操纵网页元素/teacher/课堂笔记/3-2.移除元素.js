语法：
node.removeChild(元素名，注意不是字符串);

详情见MDN

根据教师演示，在myHeading中将 img元素 删除