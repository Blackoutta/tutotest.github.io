注意，下面的'element'指代'html标签'或者被做成'const'的元素）

用来操纵HTML中的'内容'的方法:
element.textContent = ''
element.innerHTML = ''

用来操纵HTML中的'属性'的方法，这里只列举'两个'，只要'属性名'输入正确就可以操纵：
element.type = ''
element.className = ''
element.属性名 = ''
...

根据教师演示，练习：
1. 使用.textContent 将网页的标题问题进行更改；
2. 使用.innerHTML 将网页的标题更改为 images文件夹下面的图片；