上节课中我们着重讲解了'如何在网页中通过各类方法选择元素'，它们是：
document.getElementById();
document.getElementsByTagName();
document.getElementsByClassName();
document.querySelector();
document.querySelectorAll();

我们也提到了使用JS向DOM中添加互动元素的三个基本步骤：
1. 选择DOM元素 （通过上述方法）
2. 操纵DOM元素（通过函数）
3. 听取用户动作  例：element.addEventListener('类型', 函数)


本节课，我们将深入第二个步骤：操纵DOM元素；
我们将学习一些新的JS方法，来做出教师演示的页面，知识点包括：
1. 操纵HTML的内容与属性
2. 操纵CSS样式
3. 创建新元素，移除元素