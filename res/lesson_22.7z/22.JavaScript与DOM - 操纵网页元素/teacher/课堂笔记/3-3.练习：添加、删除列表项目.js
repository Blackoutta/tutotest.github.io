//知识点3：创建和移除新元素
//知识点3：创建和移除新元素
const addItemInput = document.querySelector('input.addItemInput');
const addItemButton = document.querySelector('button.addItemButton');
const removeItemButton = document.querySelector('button.removeItemButton');
//用户点击按钮时，向列表中添加一个项目
addItemButton.addEventListener('click', () => {
  let ul = document.querySelectorAll('ul')[0];
  let li = document.createElement('li');
  li.textContent = addItemInput.value;    
  ul.appendChild(li);
  addItemInput.value = '';
})
//用户点击按钮时，将列表中最后一个项目删除
removeItemButton.addEventListener('click', () => {
  let ul = document.querySelectorAll('ul')[0];
  let li = document.querySelector('li:last-child');  
  ul.removeChild(li);
})