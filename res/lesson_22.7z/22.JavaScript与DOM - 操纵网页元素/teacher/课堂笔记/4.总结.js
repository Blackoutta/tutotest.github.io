1. 用来操纵HTML中的'内容'的方法:
element.textContent = ''  //改变标签中文字的内容
element.innerHTML = ''    //改变标签中的所有内容

2. 用来操纵HTML中的'属性'的方法，这里只列举'两个'，只要'属性名'输入正确就可以操纵：
语法：
element.属性名 = ''

例子：
element.type = ''
element.className = ''
...


3. 操纵元素的CSS样式的方法
语法：
element.style.CSS属性 = ''

例子：
let myHeading = document.getElementById('myHeading');
myHeading.style.color = 'red';
myHeading.style.backgroundColor = 'gray';
myHeading.style.display = 'none';
myHeading.style.display = 'block';

4. 创建新元素，并添加到DOM中
document.createElement(元素名，注意不是字符串);  //创建
node.appendChild(元素名，注意不是字符串);        //添加

5. 移除DOM中的元素
node.removeChild(元素名，注意不是字符串);