注意，下方的node指代DOM中的元素；
element是HTML中对元素的叫法；node是DOM中对元素的叫法；
两者在大部分情况下指代的都是网页中的元素，故可以交换使用；
简单地来说，想称呼一个网页元素，你可以叫它element,也可以叫它node；


语法：
document.createElement(元素名，注意不是字符串);
node.appendChild(元素名，注意不是字符串);

详情见MDN

根据教师演示，在myHeading中添加一个 img元素