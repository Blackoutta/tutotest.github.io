//知识点2：操纵CSS样式
//知识点2：操纵CSS样式
const toggleList = document.getElementById('toggleList');
const listDiv = document.querySelector('.list');
//用户点击按钮时，将列表隐藏或显示
toggleList.addEventListener('click', () => {
  if (listDiv.style.display === "none") {
    listDiv.style.display = 'block';
    toggleList.textContent = '隐藏列表';
  } else {
    listDiv.style.display = 'none';
    toggleList.textContent = '显示列表';
  }
});