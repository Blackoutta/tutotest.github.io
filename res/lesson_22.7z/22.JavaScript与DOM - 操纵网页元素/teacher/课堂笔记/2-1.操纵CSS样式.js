语法：
element.style.CSS属性 = '';

例子：
let myHeading = document.getElementById('myHeading');
myHeading.style.color = 'red';
myHeading.style.backgroundColor = 'gray';
myHeading.style.display = 'none';
myHeading.style.display = 'block';

根据教师演示，对上方所有指令逐一进行练习；