//知识点1：操纵HTML标签中的内容与属性
//知识点1：操纵HTML标签中的内容与属性
const descriptionInput = document.querySelector('input.description');
const descriptionP = document.querySelector('p.description');
const descriptionButton = document.querySelector('button.description');
//用户点击按钮时，改变按钮旁边的标题
descriptionButton.addEventListener('click', () => {
  descriptionP.innerHTML = descriptionInput.value + ':';
  descriptionInput.value = '';
});


//-----------------------------------------------------------------------
//知识点2：操纵CSS样式
//知识点2：操纵CSS样式
const toggleList = document.getElementById('toggleList');
const listDiv = document.querySelector('.list');
//用户点击按钮时，将列表隐藏或显示
toggleList.addEventListener('click', () => {
  if (listDiv.style.display === "none") {
    listDiv.style.display = 'block';
    toggleList.textContent = '隐藏列表';
  } else {
    listDiv.style.display = 'none';
    toggleList.textContent = '显示列表';
  }
});


//-----------------------------------------------------------------------
//知识点3：创建和移除新元素
//知识点3：创建和移除新元素
const addItemInput = document.querySelector('input.addItemInput');
const addItemButton = document.querySelector('button.addItemButton');
const removeItemButton = document.querySelector('button.removeItemButton');
//用户点击按钮时，向列表中添加一个项目
addItemButton.addEventListener('click', () => {
  let ul = document.querySelectorAll('ul')[0];
  let li = document.createElement('li');
  li.textContent = addItemInput.value;    
  ul.appendChild(li);
  addItemInput.value = '';
})
//用户点击按钮时，将列表中最后一个项目删除
removeItemButton.addEventListener('click', () => {
  let ul = document.querySelectorAll('ul')[0];
  let li = document.querySelector('li:last-child');  
  ul.removeChild(li);
})