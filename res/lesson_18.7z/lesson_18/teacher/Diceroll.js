var DiceRollOne = Math.floor(Math.random() * 100) + 1;
var DiceRollTwo = Math.floor(Math.random() * 100) + 1;

alert('玩家1，想投色子，请点击确定.');
document.write('玩家1投出了' + DiceRollOne + '点！' + '<br/>');
alert('玩家2，想投色子，请点击确定.');
document.write('玩家2投出了' + DiceRollTwo + '点！')



if (DiceRollOne > DiceRollTwo) {
    document.write('<p>玩家1获胜！</p>');
} else if (DiceRollOne === DiceRollTwo ) {
    document.write('平手！');
} else {
    document.write('<p>玩家2获胜！</p>');
}