var randomNumber = Math.floor(Math.random() * 6) + 1;
var guess = prompt('我心中浮现了一个数字，它介于1-6之间，猜猜是哪个数字？');
if (parseInt(guess) === randomNumber) {
     document.write('<p>猜对了！</p>');
} else if (isNaN(guess) || guess === '' || guess > 6 || guess < 1) {
    alert('请输入一个1-6之间的数字！');
} else {
    document.write('<p>猜错了！</p>');
} 